import React, { useContext } from 'react'
import { FaBars } from 'react-icons/fa'

const Home = () => {
  return <h2>home component</h2>
}

export default Home
