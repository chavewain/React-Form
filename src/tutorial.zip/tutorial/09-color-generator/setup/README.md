#### Values JS

[values.js](https://github.com/noeldelgado/values.js)
