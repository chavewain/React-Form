import React from 'react'

const Follower = () => {
  return <h2>follower component</h2>
}

export default Follower
