import React, { useState, useEffect } from 'react';

import List from './List';
import './index.css'

function App() {

  const url = 'https://api.github.com/users'



    const [users, setUsers] = useState([])

    const getUsers = async() => {
      const response = await fetch(url)
      const users = await response.json();

      console.log(users)

      setUsers(users)
      
    }
    useEffect(() => {
      
      getUsers()
      
    }, [])

    
  return (
    <main>
      <section className="container" >
        {users.map((item) => {
          return(<p>{item.login}</p>) 
        })}
      </section>
    </main>
  )
}

export default App;