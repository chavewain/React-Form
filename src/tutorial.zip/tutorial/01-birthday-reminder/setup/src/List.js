import React, {useEffect} from 'react';

import './index.css'

const List = ({data}) => {

  useEffect(() => {
    // console.log('useEffect...')
  })

  return (
    <>
      <h3>{data.length} birthdays today</h3>

      {

        data.map((item, index) => {
          return <article key={index} className="person">
                    <img  src={item.image} />
                    <div>
                      <h4>{item.name}</h4>
                      <p>{item.age}</p>
                    </div>
                  </article>
        })
      }
      
    </>
  );
};

export default List;
