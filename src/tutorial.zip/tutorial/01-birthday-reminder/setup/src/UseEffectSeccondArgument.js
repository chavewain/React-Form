import React, { useState, useEffect } from 'react';
import data from './data';
import List from './List';
import './index.css'
function Renderx() {

  const url = 'https://api.github.com/users'

  const useEffectSeccondArgument = () => {

    const [users, setUsers] = useState([])

    const getUsers = async() => {
      const response = await fetch(url)
      const users = await response.json();

      return users
      
    }
    useEffect(() => {
      setUsers(getUsers)
    })

    

    return (<>


    </>)
  }
  
   
  

export default Renderx;
