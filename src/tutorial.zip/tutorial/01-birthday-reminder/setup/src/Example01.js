import React, { useState, useEffect } from 'react';
import data from './data';
import List from './List';
import './index.css'
function Example01() {

  const [value, setValue] = useState(window.innerWidth)

  const CheckSize = () => {
    setValue(window.innerWidth)
    console.log('setValue...')
  }

  useEffect(() => {
    console.log('useEffect...')
    window.addEventListener('resize', CheckSize)
  })
   
  
  // console.log('reRender...')
  const [items, setItems] = useState(data)
  return (
    <main>
      {value}
      <section className="container" >
        <List data={items} />
        <button onClick={() => setItems([])}>Clear all...</button>
      </section>
    </main>
  )
}

export default Example01;
